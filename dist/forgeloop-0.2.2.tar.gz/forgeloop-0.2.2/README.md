# Beyond Prompt and Pray — the trilogy

Three companion books on building trustworthy AI systems from scratch, each in
its own directory with a consistent `book/` · `code/` · `notebooks/` layout.

| Directory | Book | Focus |
|---|---|---|
| [`beyond-prompt-and-pray/`](beyond-prompt-and-pray/) | **Beyond Prompt and Pray** | Building agentic AI systems: the agent loop, typed tools, governance, memory, evaluation, and a capstone banking agent (`agentlab`). |
| [`beyond-ship-and-pray/`](beyond-ship-and-pray/) | **Beyond Ship and Pray** | Testing agentic systems: DoE-driven test design, component and system attribution, resilience (`gmstest`). |
| [`beyond-chunk-and-pray/`](beyond-chunk-and-pray/) | **Beyond Chunk and Pray** | Trustworthy RAG with geometric memory: triple-mediated retrieval, grounded synthesis, self-verification, calibrated abstention (`book_kit` + `knowlytix`). |

Each book directory contains:

- **`book/`** — the LaTeX source (and slides / reference papers where present).
- **`code/`** — the companion Python package and supporting scripts, data, and
  tests. `beyond-prompt-and-pray/code` is a pip-installable package (`agentlab`);
  install it editable with `python -m pip install -e beyond-prompt-and-pray/code`.
- **`notebooks/`** — the runnable chapter notebooks.

## Layout notes

- **One umbrella git repository.** All three books live in this single repo;
  Beyond Chunk and Pray was merged in with its full history via `git subtree`.
- **Shared data.** Ship-and-Pray's capstone harness reads some artifacts from
  Beyond Prompt and Pray's `code/data` (the two books share the governed
  complaint agent). Those paths resolve to `beyond-prompt-and-pray/code/data`.
- **Licensed substrate.** The GMS features depend on the licensed `knowlytix`
  package (see each book's `code/` README); it is not on public PyPI.

## forgeloop — the unified package and its documentation

The three books' companion code is also published as one installable package,
`forgeloop`, with `forgeloop.agents` (Prompt), `forgeloop.testing` (Ship) and
`forgeloop.rag` (Chunk). Its standalone repository carries the package and a
Sphinx documentation site — a User Guide, an API Reference and a Gallery of
Examples:

- **Repository:** https://github.com/asudjianto-xml/ForgeLoop
- **Docs:** build from that repo with `cd docs/docs && make html` (see its
  README); the User Guide distills the three books, the API Reference is
  generated from the package, and the Gallery adapts the chapter notebooks.
